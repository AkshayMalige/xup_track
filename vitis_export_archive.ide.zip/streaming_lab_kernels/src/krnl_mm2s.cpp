/**********
Copyright (c) 2020, Xilinx, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software
without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**********/


/*  */

#include "ap_axi_sdata.h"
#include "ap_int.h"
#include "hls_stream.h"
#include <iostream>
#include <string>
#include <bitset>

#define DWIDTH 32

typedef ap_axis<DWIDTH, 0, 0, 0> axis;


/**
 * @brief      This is a data mover kernel which reads data from global memory(DDR/HBM) via
 *             memory mapped interface and writes to a stream interface to another kernel
 *
 * @param[in]   in       Memory mapped interface
 * @param[out]  m2s      Output stream interface
 * @param[in]   samples  The number of samples (transactions)
 */

extern "C" {
void krnl_mm2s(ap_uint<DWIDTH>   *in,
               hls::stream<axis> &m2s,
               unsigned int      samples
               ) {
	std::cout << "Running FIR filter with MM2S " << samples << " samples \n" << std::endl;

axis v;
data_mover:
  // Auto-pipeline is going to apply pipeline to this loop
//ap_uint<32> track[samples];



int lay[8]={1,2,7,8,9,10,15,16};
int str[8];
std::cout<<"\n\nInput :\n";
  for (unsigned int i = 0; i < samples; i++) {

	  str[i] = in[i]%31;
	  std::cout<<"Channel :"<<in[i]<<" Layer "<< lay[i] <<" Straw "<<in[i]%31<<std::endl;

//	  v.data = in[i];
	  // assert last when last piece of data
//	  v.last = (i == (samples-1)) ? 1 : 0;
	  // Write to stream interface
//	  m2s.write(v);
  }

	float slope,constant,chi2;
	float sums[4];
	float XSqr =0,CriticalValue=0;
	sums[0]= 0; //xsum
	sums[1]= 0; //ysum
	sums[2]= 0;	//m=0 x2sum
	sums[3]= 0;	//c=0 xysum

	int hit_index[8]	=	{1,2,7,8,9,10,15,16};

	for(int i=0; i < samples; i++){
			sums[0]	+=	hit_index[i];
			sums[1]	+=	str[i];
			sums[2]	+=	(hit_index[i]*hit_index[i]);
			sums[3]	+=	(hit_index[i]*str[i]);
//			std::cout<<sums[0]<<"\t"<<sums[1]<<"\t"<<sums[2]<<"\t"<<sums[3]<<"\t"<<std::endl;
	}

	slope = (samples * sums[3] - sums[0] * sums[1])/(samples * sums[2] - sums[0] * sums[0]);
	constant = (sums[2] * sums[1] - sums[0] * sums[3])/(sums[2] * samples - sums[0] * sums[0]);

//	std::cout<<"xsum:"<<sums[0]<<"\t ysum :"<<sums[1]<<"\t x2sum:"<<sums[2]<<"\txysum:"<<sums[3]<<std::endl;

	x_loop :for(int f=0; f<samples; f++){
#pragma HLS pipeline
			XSqr = slope * str[f] + constant - str[f];    	//Observed[I] - Expected[I]
			CriticalValue += ((XSqr * XSqr) / str[f]);	//((XSqr * XSqr) / Expected[I])
	}
	chi2 = CriticalValue;
	std::cout<<"\n\nResult : "<<"slope :"<<slope<<" constant:"<<constant<<" chi2:"<<chi2<<std::endl;
	v.data = slope*1000;
	v.last = 0;
	m2s.write(v);
	v.data = constant*1000;
	m2s.write(v);
	v.data = chi2*1000;
	m2s.write(v);
	v.last = 1;

}
}
